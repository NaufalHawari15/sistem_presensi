<!DOCTYPE html>
<html>
<head>
    <title>Akun Diaktifkan</title>
</head>
<body>
    <h2>Halo, <?php echo e($user->name); ?>!</h2>
    <p>Kabar baik! Akun Anda telah berhasil diaktifkan oleh administrator.</p>
    <p>Anda sekarang dapat login ke aplikasi menggunakan email dan password yang telah Anda daftarkan.</p>
    <p>Terima kasih.</p>
</body>
</html><?php /**PATH F:\laragon\www\sistem_presensi\resources\views/emails/account-activated.blade.php ENDPATH**/ ?>