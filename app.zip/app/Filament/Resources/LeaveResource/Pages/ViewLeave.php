<?php

namespace App\Filament\Resources\LeaveResource\Pages;

use App\Filament\Resources\LeaveResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewLeave extends ViewRecord
{
    protected static string $resource = LeaveResource::class;

   
    protected function getHeaderActions(): array
    {
        return [
            Actions\EditAction::make(),
        ];
    }

  
    protected function mutateFormDataBeforeFill(array $data): array
    {
        $this->record->load('user');
 
        return $data;
    }
}
